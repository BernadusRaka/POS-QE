package starter.Product;

public class EditProduct {
    public void apiEditProduct() {
    }

    public void sendRequestEditProduct() {
    }

    public void productEdited() {
    }

    public void sendRequestEditProductInvalid() {
    }

    public void editProductInvalid() {
    }
}
