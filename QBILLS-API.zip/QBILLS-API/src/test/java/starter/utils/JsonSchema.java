package starter.utils;

public class JsonSchema {
    public static final String DELETE_PRODUCT_BY_ID_RESPONSE_SCHEMA = "schema/delete_product_by_id_schema.json";
    public static final String GET_ALL_PRODUCT_RESPONSE_SCHEMA = "schema/get_all_product_schema.json";
//    public static final String NO_TOKEN_RESPONSE_SCHEMA = "schema/no_token_schema.json";
    public static final String GET_PRODUCT_BY_ID_RESPONSE_SCHEMA = "schema/get_product_by_id_schema.json";
    public static final String GET_PRODUCT_BY_WRONG_ID_RESPONSE_SCHEMA = "schema/get_product_by_wrong_id_schema.json";
    public static final String GET_PRODUCT_BY_NAME_RESPONSE_SCHEMA = "schema/get_product_by_name_schema.json";
    public static final String GET_PRODUCT_BY_NAME_INVALID_RESPONSE_SCHEMA = "schema/get_product_by_name_invalid_schema.json";
    public static final String CREATE_CONVERT_POINT_RESPONSE_SCHEMA = "schema/create_convert_point_schema.json";
//    public static final String CREATE_CONVERT_POINT_INVALID_RESPONSE_SCHEMA = "schema/create_convert_point_invalid_schema.json";
    public static final String DELETE_CONVERT_POINT_RESPONSE_SCHEMA = "schema/delete_convert_point_schema.json";
    public static final String UPDATE_CONVERT_POINT_RESPONSE_SCHEMA = "schema/update_convert_point_schema.json";
    public static final String GET_ALL_CONVERT_POINT_RESPONSE_SCHEMA = "schema/get_all_convert_point_schema.json";
    public static final String GET_CONVERT_POINT_BY_ID_INVALID_RESPONSE_SCHEMA = "schema/get_convert_point_by_id_invalid_schema.json";
    public static final String GET_CONVERT_POINT_BY_ID_RESPONSE_SCHEMA = "schema/get_convert_point_by_id_schema.json";
    public static final String GET_ALL_PAYMENT_METHOD_RESPONSE_SCHEMA = "schema/get_all_payment_method_schema.json";
    public static final String GET_PAYMENT_METHOD_BY_ID_RESPONSE_SCHEMA = "schema/get_payment_method_by_id_schema.json";
    public static final String GET_PAYMENT_METHOD_INVALID_ID_RESPONSE_SCHEMA = "schema/get_payment_method_invalid_id_schema.json";
    public static final String DELETE_PAYMENT_METHOD_RESPONSE_SCHEMA = "schema/delete_payment_method_schema.json";
    public static final String GET_PAYMENT_METHOD_BY_NAME_RESPONSE_SCHEMA = "schema/get_payment_method_by_name_schema.json";
    public static final String GET_PAYMENT_METHOD_BY_NAME_INVALID_RESPONSE_SCHEMA = "schema/get_payment_method_by_name_invalid_schema.json";
    public static final String CREATE_PAYMENT_METHOD_INVALID_RESPONSE_SCHEMA = "schema/create_payment_method_invalid_schema.json";
    public static final String CREATE_PAYMENT_METHOD_RESPONSE_SCHEMA = "schema/create_payment_method_schema.json";
    public static final String UPDATE_PAYMENT_METHOD_RESPONSE_SCHEMA = "schema/update_payment_method_schema.json";
}
