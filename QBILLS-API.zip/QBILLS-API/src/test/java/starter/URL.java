package starter;

public class URL {

    public static String urlAdmin = "https://qbills.biz.id/api/v1/admin/";
    public static String urlProduct = "https://qbills.biz.id/api/v1/product";
    public static String urlConvertPoint = "https://qbills.biz.id//api/v1/convert/point";
    public static String urlInvalidConvertPoint = "https://qbills.biz.id//api/v1/convert/pointtt";
    public static String urlPaymentMethod = "https://qbills.biz.id/api/v1/payment/method";

}
